var UILayer = {
    select: {
        citySelect: document.querySelector("#citySelect"),
    },
    btn: {
        getReportBtn: document.querySelector("#getReportBtn"),
    },
    div: {
        weatherReportInfoPara: document.querySelector(".weatherRepostInfo"),
        locationDiv: document.querySelector(".locationDiv"),
        celciusDiv: document.querySelector(".celciusDiv"),
        windInfoDiv: document.querySelector(".windInfoDiv"),
        iconDiv: document.querySelector(".iconDiv"),
        celciusDiv: document.querySelector(".celciusDiv"),
        windDiv: document.querySelector(".windDiv"),
        precipDiv: document.querySelector(".precipDiv"),
        psressureDiv: document.querySelector(".psressureDiv"),
        weatherDiscDiv: document.querySelector(".weatherDiscDiv")

    }

}

UILayer.btn.getReportBtn.addEventListener("click", getWeatherReport);

function getWeatherReport() {
    var cityName = UILayer.select.citySelect.value,
        url = "http://api.weatherstack.com/current?access_key=d2b53ef81cd308f5836a6b53f075914f&query=" + cityName,
        xhttp = new XMLHttpRequest(),
        weatherRepostInfo;
    xhttp.onreadystatechange = function () {
        if (this.readyState == 4 && this.status == 200) {
            weatherRepostInfo = JSON.parse(this.responseText);
            weatherRepostInfo && setWeatherInfo(weatherRepostInfo);
        }
    };
    xhttp.open("GET", url, true);
    xhttp.send();
}

function setWeatherInfo(weatherRepostInfo) {
    UILayer.div.weatherReportInfoPara.setAttribute("class","borderStyle");
    UILayer.div.locationDiv.innerHTML=weatherRepostInfo.location.name+", "+weatherRepostInfo.location.region+", "+weatherRepostInfo.location.country;
    UILayer.div.iconDiv.src=weatherRepostInfo.current.weather_icons[0];
    UILayer.div.celciusDiv.innerHTML = "Temp :" + weatherRepostInfo.current.temperature +'&#8451';
    UILayer.div.windDiv.innerHTML = "Wind Speed :" +weatherRepostInfo.current.wind_speed;
    UILayer.div.precipDiv.innerHTML = "Precip :" + weatherRepostInfo.current.precip;
    UILayer.div.psressureDiv.innerHTML = "Pressure :"+weatherRepostInfo.current.pressure;
    UILayer.div.weatherDiscDiv.innerHTML = "Weather Descriptions : "+weatherRepostInfo.current.weather_descriptions[0];
}
